#include <stdio.h>
#include <iostream>

using namespace std;

void drawLine(int size, string ch){
    for(int i=0;i<size;i++){
        cout << ch;
    }
}

void drawTriangle(int size) {
    int i=0;
    int j=0;
    for(i=0; i<size;i++){
        drawLine(i+1, "x");
        cout << "\n";
    }
}
void drawRectangle(int size) {
    int i=0;
    int j=0;
    //int k=0;
    for(i=0;i<size;i++){
        if(i==0) {
            drawLine(size, "x");
            cout << "\n";
        }
        drawLine(1, "x");
        drawLine(size-2, " ");
        drawLine(1, "x");
        cout << "\n";
        if(i+1 == size ) {
            drawLine(size, "x");
            cout << "\n";
        }
    }
}

void drawPiramid(int size, int t=0){
    int i=0;
    int max=t;
    if(!t) {
        max = size*2+1;
    }
    int c=1;
    int spacje=1;
    int srodek = max/2;
    for(i=0;i<size;i++) {
        drawLine(srodek-spacje, " ");
        drawLine(c, "x");
        c += 2;
        spacje += 1;
        cout << "\n";
    }
}

void drawChristmasTree(int size){
    int maximum = size*2+1;
    for(int i=1;i<=size;i++) {
        drawPiramid(i, maximum);
    }
}

int main(){
	const int MAXLINE=100;
	char line[MAXLINE];
	char oneChar;
	int value;
	while(true){
		cin >> oneChar;
		if(oneChar=='#')
		{
			cin.getline(line, MAXLINE);
			continue;
		}
		if(oneChar=='E')
			break;
		// read next argument, one int value
		cin >> value;
		switch(oneChar){
		case 'T': drawTriangle(value); break;
		case 'R': drawRectangle(value); break;
		case 'P': drawPiramid(value); break;
		case 'C': drawChristmasTree(value); break;
		}
	}
}
